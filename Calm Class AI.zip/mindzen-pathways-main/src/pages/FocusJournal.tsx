import { useState } from "react";
import Layout from "@/components/Layout";
import { useLearningState } from "@/contexts/LearningStateContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid } from "recharts";
import { Download } from "lucide-react";

export default function FocusJournal() {
  const { stats } = useLearningState();
  const [dateRange, setDateRange] = useState("today");

  // Generate sample data for charts
  const focusTimeData = [
    { time: "9AM", focus: 45 },
    { time: "10AM", focus: 65 },
    { time: "11AM", focus: 85 },
    { time: "12PM", focus: 70 },
    { time: "1PM", focus: 55 },
    { time: "2PM", focus: 75 },
    { time: "3PM", focus: 60 },
    { time: "4PM", focus: 50 },
  ];

  // Use actual stats for emotion patterns
  const emotionData = [
    { name: "Calm", value: stats.emotionPatterns.calm, fill: "hsl(var(--sky))" },
    { name: "Fatigue", value: stats.emotionPatterns.fatigue, fill: "hsl(var(--lavender))" },
    { name: "Distraction", value: stats.emotionPatterns.distraction, fill: "hsl(var(--peach))" },
  ];

  const formatBestLearningTime = () => {
    const start = stats.bestLearningHour;
    const end = (start + 2) % 24;
    const formatHour = (h: number) => {
      if (h === 0) return "12 AM";
      if (h === 12) return "12 PM";
      return h > 12 ? `${h - 12} PM` : `${h} AM`;
    };
    return `${formatHour(start)} – ${formatHour(end)}`;
  };

  const downloadReport = () => {
    const report = {
      dateRange,
      focusHistory: stats.focusHistory,
      emotionPatterns: stats.emotionPatterns,
      bestLearningTime: formatBestLearningTime(),
      totalTimeStudied: `${Math.floor(stats.totalTimeStudied / 3600)}h ${Math.floor((stats.totalTimeStudied % 3600) / 60)}m`,
      generatedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "focus-journal-report.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="font-display text-2xl md:text-3xl font-bold">Focus Journal</h1>
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Date" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          {/* Focus vs Time Chart */}
          <Card className="calm-card lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg">Focus vs. Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={focusTimeData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="time" 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                    />
                    <YAxis 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                      label={{ 
                        value: 'Focus', 
                        angle: -90, 
                        position: 'insideLeft',
                        fill: 'hsl(var(--muted-foreground))'
                      }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="focus" 
                      stroke="hsl(var(--sky))" 
                      strokeWidth={3}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="text-center text-sm text-muted-foreground mt-2">Time</p>
            </CardContent>
          </Card>

          {/* Insight Card */}
          <div className="space-y-4">
            <Card className="calm-card">
              <CardHeader>
                <CardTitle className="text-lg">Insight</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Best learning time:<br />
                  <span className="text-xl font-semibold text-foreground">{formatBestLearningTime()}</span>
                </p>
              </CardContent>
            </Card>

            <Card className="calm-card">
              <CardContent className="pt-6 space-y-4">
                <Button variant="outline" className="w-full" onClick={downloadReport}>
                  <Download className="w-4 h-4 mr-2" />
                  Download Report
                </Button>
                <p className="text-sm text-muted-foreground">
                  Best learning time:<br />
                  <span className="font-semibold text-foreground">{formatBestLearningTime()}</span>
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Emotion Pattern */}
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="calm-card">
            <CardHeader>
              <CardTitle className="text-lg">Emotion Pattern</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {emotionData.map((emotion) => (
                  <div key={emotion.name} className="flex items-center gap-3">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: emotion.fill }}
                    />
                    <span className="text-sm flex-1">{emotion.name}</span>
                    <span className="text-sm font-medium">{emotion.value}%</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="calm-card lg:col-span-2">
            <CardContent className="pt-6">
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={emotionData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis 
                      dataKey="name" 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                    />
                    <YAxis 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Bar dataKey="value" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bottom Stats */}
        <div className="flex items-center justify-end gap-4 text-sm">
          <span className="text-2xl font-bold text-primary">
            {Math.round(100 - stats.emotionPatterns.distraction)}%
          </span>
          <span className="text-muted-foreground">Calm Mode</span>
        </div>
      </div>
    </Layout>
  );
}
