import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { MessageCircle, Wind, BookOpen, SmilePlus, Play, Coffee, Sparkles } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useLearningState } from "@/contexts/LearningStateContext";
import { supabase } from "@/integrations/supabase/client";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from "recharts";

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { state, stats, currentLesson, insight } = useLearningState();
  const [name, setName] = useState<string>("");

  useEffect(() => {
    const fetchProfile = async () => {
      if (!user) return;
      const { data: profile } = await supabase
        .from("profiles")
        .select("name")
        .eq("user_id", user.id)
        .maybeSingle();
      if (profile?.name) {
        setName(profile.name);
      }
    };
    fetchProfile();
  }, [user]);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${h}h ${m.toString().padStart(2, "0")}m`;
  };

  // Generate attention chart data based on focus history or sample
  const attentionData = stats.focusHistory.length > 5
    ? stats.focusHistory.slice(-8).map((f, i) => ({ time: i, attention: f.value }))
    : [
        { time: 0, attention: 50 },
        { time: 1, attention: 60 },
        { time: 2, attention: 55 },
        { time: 3, attention: 75 },
        { time: 4, attention: 85 },
        { time: 5, attention: 70 },
        { time: 6, attention: 65 },
      ];

  const getEmotionInsight = () => {
    if (state.fatigue > 70) return { text: "Detected fatigue", action: "Take a break" };
    if (state.focus > 80) return { text: "Great focus!", action: "Keep it up" };
    if (state.calm < 50) return { text: "Feeling tense?", action: "Try breathing" };
    return { text: "Balanced state", action: "Ready to learn" };
  };

  const emotionInsight = getEmotionInsight();

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="font-display text-2xl md:text-3xl font-bold">
            Today's Focus Summary
          </h1>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {/* Time Studied */}
          <Card className="calm-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-muted-foreground font-normal">Time Studied</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{formatTime(stats.totalTimeStudied)}</p>
            </CardContent>
          </Card>

          {/* Attention Chart */}
          <Card className="calm-card row-span-2">
            <CardContent className="pt-6">
              <div className="h-40">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={attentionData}>
                    <XAxis dataKey="time" hide />
                    <YAxis hide domain={[0, 100]} />
                    <Line 
                      type="monotone" 
                      dataKey="attention" 
                      stroke="hsl(var(--sky))" 
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>Attention</span>
                <span>Time</span>
              </div>
            </CardContent>
          </Card>

          {/* Breaks Taken */}
          <Card className="calm-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-muted-foreground font-normal">Breaks Taken</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{stats.breaksTaken}</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {/* Current Lesson */}
          <Card className="calm-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold">Current Lesson</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {currentLesson ? (
                <>
                  <p className="text-sm text-muted-foreground">{currentLesson.title}</p>
                  <Progress value={currentLesson.progress} className="h-3" />
                  <Button 
                    className="w-full"
                    onClick={() => navigate("/lessons")}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Resume
                  </Button>
                </>
              ) : (
                <>
                  <p className="text-sm text-muted-foreground">No lesson in progress</p>
                  <Progress value={0} className="h-3" />
                  <Button 
                    variant="outline"
                    className="w-full"
                    onClick={() => navigate("/lessons")}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Start a Lesson
                  </Button>
                </>
              )}
            </CardContent>
          </Card>

          {/* Emotion Insight */}
          <Card className="calm-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                Emotion Insight
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-lg">{emotionInsight.text}</p>
              <p className="text-muted-foreground">{emotionInsight.action}</p>
              
              {insight && (
                <div className="p-3 bg-sky-light rounded-lg mt-4">
                  <p className="text-sm">{insight}</p>
                </div>
              )}

              {state.fatigue > 60 && (
                <Button variant="outline" className="w-full mt-2" onClick={() => navigate("/breathing")}>
                  <Wind className="w-4 h-4 mr-2" />
                  Take a break
                </Button>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link to="/lessons" className="calm-card flex flex-col items-center p-4 hover:shadow-soft">
            <BookOpen className="w-8 h-8 text-primary mb-2" />
            <span className="font-medium text-sm">Lessons</span>
          </Link>
          <Link to="/focus-journal" className="calm-card flex flex-col items-center p-4 hover:shadow-soft">
            <Sparkles className="w-8 h-8 text-sky mb-2" />
            <span className="font-medium text-sm">Focus Journal</span>
          </Link>
          <Link to="/breathing" className="calm-card flex flex-col items-center p-4 hover:shadow-soft">
            <Wind className="w-8 h-8 text-mint mb-2" />
            <span className="font-medium text-sm">Breathing</span>
          </Link>
          <Link to="/settings" className="calm-card flex flex-col items-center p-4 hover:shadow-soft">
            <Coffee className="w-8 h-8 text-peach mb-2" />
            <span className="font-medium text-sm">Settings</span>
          </Link>
        </div>
      </div>
    </Layout>
  );
}
