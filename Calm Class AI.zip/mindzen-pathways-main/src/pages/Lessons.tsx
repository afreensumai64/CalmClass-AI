import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/Layout";
import { useLearningState } from "@/contexts/LearningStateContext";
import { useComfortPreferences } from "@/contexts/ComfortPreferencesContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronLeft, ChevronRight, Play, Pause, Coffee, Smile, BookOpen, Presentation, Headphones } from "lucide-react";
import { cn } from "@/lib/utils";

const SAMPLE_LESSONS = [
  { id: "1", title: "Introduction to Mindfulness", content: "Mindfulness is the practice of being fully present and engaged in the moment, aware of your thoughts and feelings without distraction or judgment..." },
  { id: "2", title: "Study Techniques for Focus", content: "Effective studying isn't about the hours you put in, but how you use those hours. The Pomodoro Technique, spaced repetition, and active recall are proven methods..." },
  { id: "3", title: "Managing Test Anxiety", content: "Test anxiety is common and manageable. Understanding the physiological response to stress can help you develop coping strategies..." },
];

export default function Lessons() {
  const navigate = useNavigate();
  const { state, currentLesson, startLesson, updateLessonProgress, changePace, changeMode, takeBreak, endLesson, tickLearning, insight } = useLearningState();
  const { isMinimalAnimations } = useComfortPreferences();
  
  const [selectedLesson, setSelectedLesson] = useState<typeof SAMPLE_LESSONS[0] | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  // Auto-select current lesson if exists
  useEffect(() => {
    if (currentLesson && !selectedLesson) {
      const lesson = SAMPLE_LESSONS.find(l => l.id === currentLesson.lessonId);
      if (lesson) setSelectedLesson(lesson);
    }
  }, [currentLesson, selectedLesson]);

  // Tick learning state every 30 seconds while playing
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      tickLearning();
      // Simulate progress increase
      if (currentLesson && currentLesson.progress < 100) {
        updateLessonProgress(currentLesson.progress + 2 * (currentLesson.pace || 1));
      }
    }, 30000);
    return () => clearInterval(interval);
  }, [isPlaying, tickLearning, currentLesson, updateLessonProgress]);

  const handleStartLesson = (lesson: typeof SAMPLE_LESSONS[0]) => {
    setSelectedLesson(lesson);
    startLesson(lesson.id, lesson.title);
    setIsPlaying(true);
  };

  const handleEndLesson = () => {
    endLesson();
    setSelectedLesson(null);
    setIsPlaying(false);
    navigate("/");
  };

  const handlePaceChange = (direction: "slower" | "faster") => {
    if (!currentLesson) return;
    const newPace = direction === "faster" 
      ? Math.min(2, (currentLesson.pace || 1) + 0.25)
      : Math.max(0.5, (currentLesson.pace || 1) - 0.25);
    changePace(newPace);
  };

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case "text": return BookOpen;
      case "slides": return Presentation;
      case "audio": return Headphones;
      default: return BookOpen;
    }
  };

  // Lesson selection view
  if (!selectedLesson) {
    return (
      <Layout>
        <div className="space-y-6 animate-fade-in">
          <h1 className="font-display text-2xl md:text-3xl font-bold">Lessons</h1>
          <div className="grid gap-4">
            {SAMPLE_LESSONS.map((lesson) => (
              <Card key={lesson.id} className="calm-card cursor-pointer hover:shadow-soft" onClick={() => handleStartLesson(lesson)}>
                <CardContent className="p-6 flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">{lesson.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {lesson.content.substring(0, 80)}...
                    </p>
                  </div>
                  <Button variant="outline" size="icon">
                    <Play className="w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  // Active lesson view
  return (
    <Layout>
      <div className={cn("space-y-4", !isMinimalAnimations && "animate-fade-in")}>
        {/* Lesson Header */}
        <Card className="calm-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h1 className="font-display text-xl font-bold">{selectedLesson.title}</h1>
              <Smile className="w-8 h-8 text-primary" />
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium">{Math.round(currentLesson?.progress || 0)}%</span>
              </div>
              <Progress value={currentLesson?.progress || 0} className="h-3" />
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-3">
          {/* Content Area */}
          <div className="md:col-span-2">
            <Card className="calm-card h-full">
              <CardContent className="p-6">
                <Tabs value={currentLesson?.mode || "text"} onValueChange={(v) => changeMode(v as any)}>
                  <TabsList className="mb-4">
                    <TabsTrigger value="text" className="gap-2">
                      <BookOpen className="w-4 h-4" /> Text
                    </TabsTrigger>
                    <TabsTrigger value="slides" className="gap-2">
                      <Presentation className="w-4 h-4" /> Slides
                    </TabsTrigger>
                    <TabsTrigger value="audio" className="gap-2">
                      <Headphones className="w-4 h-4" /> Audio
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="text" className="min-h-[200px]">
                    <p className="text-foreground leading-relaxed">{selectedLesson.content}</p>
                  </TabsContent>
                  <TabsContent value="slides" className="min-h-[200px] flex items-center justify-center bg-muted/30 rounded-lg">
                    <p className="text-muted-foreground">Slide presentation mode</p>
                  </TabsContent>
                  <TabsContent value="audio" className="min-h-[200px] flex items-center justify-center bg-muted/30 rounded-lg">
                    <p className="text-muted-foreground">Audio narration mode</p>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Micro-Break Card */}
          <Card className="calm-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Coffee className="w-5 h-5" />
                Take a Micro-Break
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Stretch, breathe, or have a sip of water.
              </p>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={takeBreak}
              >
                Take a Break
              </Button>
              
              {insight && (
                <div className="mt-4 p-3 bg-sky-light rounded-lg">
                  <p className="text-sm text-sky-foreground">{insight}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Controls Bar */}
        <Card className="calm-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handlePaceChange("slower")}
                  className="gap-1"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Slower
                </Button>
                
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setIsPlaying(!isPlaying)}
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setIsPlaying(!isPlaying)}
                  >
                    <Play className="w-4 h-4" />
                  </Button>
                </div>
                
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handlePaceChange("faster")}
                  className="gap-1"
                >
                  Faster
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-sm text-muted-foreground">
                  Pace: {((currentLesson?.pace || 1) * 100).toFixed(0)}%
                </div>
                <div className="text-sm font-medium">
                  Calm Mode
                </div>
                <Button variant="outline" size="sm" onClick={handleEndLesson}>
                  End Lesson
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bottom Controls */}
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <Button variant="ghost" size="sm" onClick={handleEndLesson}>
            <ChevronLeft className="w-4 h-4 mr-1" />
            Pace Control
          </Button>
          <div className="flex items-center gap-2">
            <Play className="w-4 h-4" />
          </div>
          <div className="flex items-center gap-4">
            <span>{Math.round(currentLesson?.progress || 0)}%</span>
            <span>Calm Mode</span>
          </div>
        </div>
      </div>
    </Layout>
  );
}
