import Layout from "@/components/Layout";
import { useComfortPreferences, FontType, ColorTheme, AnimationMode } from "@/contexts/ComfortPreferencesContext";
import { useLearningState } from "@/contexts/LearningStateContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Smile, Download } from "lucide-react";

export default function Settings() {
  const { preferences, updatePreference } = useComfortPreferences();
  const { stats } = useLearningState();

  const formatBestLearningTime = () => {
    const start = stats.bestLearningHour;
    const end = (start + 2) % 24;
    const formatHour = (h: number) => {
      if (h === 0) return "12 AM";
      if (h === 12) return "12 PM";
      return h > 12 ? `${h - 12} PM` : `${h} AM`;
    };
    return `${formatHour(start)} – ${formatHour(end)}`;
  };

  const downloadReport = () => {
    const report = {
      preferences,
      stats: {
        ...stats,
        totalTimeStudiedFormatted: `${Math.floor(stats.totalTimeStudied / 3600)}h ${Math.floor((stats.totalTimeStudied % 3600) / 60)}m`,
      },
      generatedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "calmclass-report.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-2xl md:text-3xl font-bold">
            Comfort Preferences
          </h1>
          <Smile className="w-8 h-8 text-primary" />
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {/* Font Type */}
          <Card className="calm-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-medium">Font Type</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Button
                  variant={preferences.font === "default" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => updatePreference("font", "default" as FontType)}
                >
                  Default
                </Button>
                <Button
                  variant={preferences.font === "opendyslexic" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => updatePreference("font", "opendyslexic" as FontType)}
                >
                  OpenDyslexic
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Color Palette */}
          <Card className="calm-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-medium flex items-center justify-between">
                Color Palette
                <Smile className="w-5 h-5 text-muted-foreground" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Button
                  variant={preferences.colorTheme === "calm-blue" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => updatePreference("colorTheme", "calm-blue" as ColorTheme)}
                >
                  Calm Blue
                </Button>
                <Button
                  variant={preferences.colorTheme === "low-contrast" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => updatePreference("colorTheme", "low-contrast" as ColorTheme)}
                >
                  Low Contrast
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Animation Mode */}
          <Card className="calm-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-medium">Animation Mode</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Button
                  variant={preferences.animationMode === "minimal" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => updatePreference("animationMode", "minimal" as AnimationMode)}
                >
                  Minimal
                </Button>
                <Button
                  variant={preferences.animationMode === "standard" ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => updatePreference("animationMode", "standard" as AnimationMode)}
                >
                  Standard
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Insight Card */}
          <Card className="calm-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-medium">Insight</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Best learning time: <span className="font-semibold text-foreground">{formatBestLearningTime()}</span>
              </p>
              <Button variant="outline" className="w-full" onClick={downloadReport}>
                <Download className="w-4 h-4 mr-2" />
                Download Report
              </Button>
            </CardContent>
          </Card>

          {/* Notification Style */}
          <Card className="calm-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-medium">Notification Style</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Button
                  variant={preferences.notificationsEnabled ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => updatePreference("notificationsEnabled", true)}
                >
                  On
                </Button>
                <Button
                  variant={!preferences.notificationsEnabled ? "default" : "outline"}
                  className="flex-1"
                  onClick={() => updatePreference("notificationsEnabled", false)}
                >
                  Off
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Emotion Tracking */}
          <Card className="calm-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-medium">Emotion Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  Track focus, fatigue & calm levels
                </span>
                <Switch
                  checked={preferences.emotionTrackingEnabled}
                  onCheckedChange={(checked) => updatePreference("emotionTrackingEnabled", checked)}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
