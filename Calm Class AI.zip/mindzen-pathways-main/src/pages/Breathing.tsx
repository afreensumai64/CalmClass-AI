import { useState, useEffect, useCallback } from "react";
import { Play, Pause, RotateCcw } from "lucide-react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type BreathingMode = "calm" | "focus" | "sleep";
type Phase = "inhale" | "hold" | "exhale" | "rest";

interface ModeConfig {
  name: string;
  description: string;
  inhale: number;
  hold: number;
  exhale: number;
  rest: number;
  color: string;
  bgColor: string;
}

const modes: Record<BreathingMode, ModeConfig> = {
  calm: {
    name: "Calm",
    description: "4-7-8 breathing for relaxation",
    inhale: 4,
    hold: 7,
    exhale: 8,
    rest: 0,
    color: "bg-lavender",
    bgColor: "bg-lavender-light",
  },
  focus: {
    name: "Focus",
    description: "Box breathing for concentration",
    inhale: 4,
    hold: 4,
    exhale: 4,
    rest: 4,
    color: "bg-sky",
    bgColor: "bg-sky-light",
  },
  sleep: {
    name: "Sleep",
    description: "Deep breathing for restfulness",
    inhale: 5,
    hold: 5,
    exhale: 7,
    rest: 3,
    color: "bg-mint",
    bgColor: "bg-mint-light",
  },
};

const phaseMessages: Record<Phase, string> = {
  inhale: "Breathe in...",
  hold: "Hold...",
  exhale: "Breathe out...",
  rest: "Rest...",
};

export default function Breathing() {
  const [mode, setMode] = useState<BreathingMode>("calm");
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<Phase>("inhale");
  const [countdown, setCountdown] = useState(modes[mode].inhale);
  const [cycles, setCycles] = useState(0);

  const config = modes[mode];

  const getNextPhase = useCallback((currentPhase: Phase): Phase => {
    const sequence: Phase[] = ["inhale", "hold", "exhale", "rest"];
    const currentIndex = sequence.indexOf(currentPhase);
    
    // Skip phases with 0 duration
    let nextIndex = (currentIndex + 1) % sequence.length;
    while (config[sequence[nextIndex]] === 0) {
      nextIndex = (nextIndex + 1) % sequence.length;
    }
    
    return sequence[nextIndex];
  }, [config]);

  const getPhaseDuration = useCallback((p: Phase): number => {
    return config[p];
  }, [config]);

  useEffect(() => {
    if (!isActive) return;

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          const nextPhase = getNextPhase(phase);
          setPhase(nextPhase);
          
          if (nextPhase === "inhale") {
            setCycles((c) => c + 1);
          }
          
          return getPhaseDuration(nextPhase);
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isActive, phase, getNextPhase, getPhaseDuration]);

  const toggleActive = () => {
    if (!isActive) {
      setPhase("inhale");
      setCountdown(config.inhale);
    }
    setIsActive(!isActive);
  };

  const reset = () => {
    setIsActive(false);
    setPhase("inhale");
    setCountdown(config.inhale);
    setCycles(0);
  };

  const changeMode = (newMode: BreathingMode) => {
    setMode(newMode);
    setIsActive(false);
    setPhase("inhale");
    setCountdown(modes[newMode].inhale);
    setCycles(0);
  };

  const getCircleScale = () => {
    if (!isActive) return "scale-75";
    switch (phase) {
      case "inhale":
        return "scale-100";
      case "hold":
        return "scale-100";
      case "exhale":
        return "scale-75";
      case "rest":
        return "scale-75";
    }
  };

  const getTransitionDuration = () => {
    return `${getPhaseDuration(phase)}s`;
  };

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)] lg:min-h-[calc(100vh-6rem)] animate-fade-in">
        {/* Mode Selector */}
        <div className="flex gap-2 mb-8 p-1 bg-muted rounded-xl">
          {(Object.keys(modes) as BreathingMode[]).map((m) => (
            <button
              key={m}
              onClick={() => changeMode(m)}
              className={cn(
                "px-4 py-2 rounded-lg font-medium transition-all duration-200",
                mode === m
                  ? "bg-card shadow-sm text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {modes[m].name}
            </button>
          ))}
        </div>

        {/* Breathing Circle */}
        <div className="relative flex items-center justify-center mb-8">
          {/* Outer glow */}
          <div
            className={cn(
              "absolute w-64 h-64 md:w-80 md:h-80 rounded-full transition-all opacity-30",
              config.bgColor,
              getCircleScale()
            )}
            style={{ transitionDuration: getTransitionDuration() }}
          />
          
          {/* Main circle */}
          <div
            className={cn(
              "w-48 h-48 md:w-64 md:h-64 rounded-full flex items-center justify-center transition-all",
              config.color,
              getCircleScale()
            )}
            style={{ transitionDuration: getTransitionDuration() }}
          >
            <div className="text-center text-primary-foreground">
              <p className="text-5xl md:text-6xl font-bold font-display">{countdown}</p>
              <p className="text-lg md:text-xl mt-2 opacity-90">
                {isActive ? phaseMessages[phase] : "Ready"}
              </p>
            </div>
          </div>
        </div>

        {/* Mode Description */}
        <p className="text-muted-foreground text-center mb-6 max-w-sm">
          {config.description}
        </p>

        {/* Controls */}
        <div className="flex gap-4">
          <Button
            onClick={toggleActive}
            size="lg"
            className={cn("calm-button h-14 w-14 rounded-full p-0", config.color, "hover:opacity-90")}
          >
            {isActive ? (
              <Pause className="w-6 h-6" />
            ) : (
              <Play className="w-6 h-6 ml-0.5" />
            )}
          </Button>
          <Button
            onClick={reset}
            size="lg"
            variant="outline"
            className="calm-button h-14 w-14 rounded-full p-0"
          >
            <RotateCcw className="w-5 h-5" />
          </Button>
        </div>

        {/* Cycle Counter */}
        {cycles > 0 && (
          <div className="mt-8 calm-card py-3 px-6">
            <p className="text-muted-foreground">
              Completed <span className="font-semibold text-foreground">{cycles}</span> cycle{cycles !== 1 && "s"}
            </p>
          </div>
        )}

        {/* Instructions */}
        <div className="mt-8 calm-card max-w-md text-center">
          <h3 className="font-semibold mb-2">How it works</h3>
          <p className="text-sm text-muted-foreground">
            {mode === "calm" && "The 4-7-8 technique: Inhale for 4 seconds, hold for 7, exhale for 8. This activates your parasympathetic nervous system."}
            {mode === "focus" && "Box breathing: Equal counts of 4 for each phase. Used by athletes and performers to enhance focus and calm."}
            {mode === "sleep" && "Extended exhale breathing: Longer exhales than inhales promote deep relaxation and prepare your body for sleep."}
          </p>
        </div>
      </div>
    </Layout>
  );
}
