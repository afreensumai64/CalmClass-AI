import { useState, useEffect } from "react";
import { Plus, Check, Trash2, Calendar, BookOpen } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, isPast, isToday, isTomorrow } from "date-fns";

interface Task {
  id: string;
  subject: string;
  title: string;
  deadline: string | null;
  completed: boolean;
  created_at: string;
}

export default function Planner() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ subject: "", title: "", deadline: "" });

  useEffect(() => {
    fetchTasks();
  }, [user]);

  const fetchTasks = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from("study_tasks")
      .select("*")
      .eq("user_id", user.id)
      .order("deadline", { ascending: true, nullsFirst: false })
      .order("created_at", { ascending: false });

    if (error) {
      toast({ title: "Error loading tasks", variant: "destructive" });
    } else {
      setTasks(data || []);
    }
    setLoading(false);
  };

  const addTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !form.subject.trim() || !form.title.trim()) return;

    const { error } = await supabase.from("study_tasks").insert({
      user_id: user.id,
      subject: form.subject.trim(),
      title: form.title.trim(),
      deadline: form.deadline || null,
    });

    if (error) {
      toast({ title: "Error adding task", variant: "destructive" });
    } else {
      toast({ title: "Task added! 📚" });
      setForm({ subject: "", title: "", deadline: "" });
      setShowForm(false);
      fetchTasks();
    }
  };

  const toggleComplete = async (task: Task) => {
    const { error } = await supabase
      .from("study_tasks")
      .update({ completed: !task.completed })
      .eq("id", task.id);

    if (error) {
      toast({ title: "Error updating task", variant: "destructive" });
    } else {
      setTasks((prev) =>
        prev.map((t) => (t.id === task.id ? { ...t, completed: !t.completed } : t))
      );
      if (!task.completed) {
        toast({ title: "Great job! 🎉" });
      }
    }
  };

  const deleteTask = async (id: string) => {
    const { error } = await supabase.from("study_tasks").delete().eq("id", id);

    if (error) {
      toast({ title: "Error deleting task", variant: "destructive" });
    } else {
      setTasks((prev) => prev.filter((t) => t.id !== id));
      toast({ title: "Task removed" });
    }
  };

  const getDeadlineLabel = (deadline: string | null) => {
    if (!deadline) return null;
    const date = new Date(deadline);
    if (isToday(date)) return "Today";
    if (isTomorrow(date)) return "Tomorrow";
    if (isPast(date)) return "Overdue";
    return format(date, "MMM d");
  };

  const getDeadlineColor = (deadline: string | null, completed: boolean) => {
    if (completed || !deadline) return "text-muted-foreground";
    const date = new Date(deadline);
    if (isPast(date)) return "text-destructive";
    if (isToday(date) || isTomorrow(date)) return "text-orange-500";
    return "text-muted-foreground";
  };

  const completedCount = tasks.filter((t) => t.completed).length;
  const progress = tasks.length > 0 ? (completedCount / tasks.length) * 100 : 0;

  // Group tasks by subject
  const subjects = [...new Set(tasks.map((t) => t.subject))];

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-mint-light flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-mint" />
            </div>
            <div>
              <h1 className="font-display font-bold text-xl">Study Planner</h1>
              <p className="text-sm text-muted-foreground">{tasks.length} tasks total</p>
            </div>
          </div>
          <Button onClick={() => setShowForm(!showForm)} className="calm-button">
            <Plus className="w-4 h-4 mr-2" />
            Add Task
          </Button>
        </div>

        {/* Progress */}
        {tasks.length > 0 && (
          <div className="calm-card">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Progress</span>
              <span className="text-sm text-muted-foreground">
                {completedCount}/{tasks.length} completed
              </span>
            </div>
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-mint rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {/* Add Task Form */}
        {showForm && (
          <form onSubmit={addTask} className="calm-card space-y-4 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  placeholder="e.g., Mathematics"
                  value={form.subject}
                  onChange={(e) => setForm({ ...form, subject: e.target.value })}
                  className="calm-input"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="deadline">Deadline (optional)</Label>
                <Input
                  id="deadline"
                  type="date"
                  value={form.deadline}
                  onChange={(e) => setForm({ ...form, deadline: e.target.value })}
                  className="calm-input"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="title">Task</Label>
              <Input
                id="title"
                placeholder="e.g., Complete chapter 5 exercises"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="calm-input"
                required
              />
            </div>
            <div className="flex gap-2">
              <Button type="submit" className="calm-button">
                Add Task
              </Button>
              <Button
                type="button"
                variant="ghost"
                onClick={() => setShowForm(false)}
              >
                Cancel
              </Button>
            </div>
          </form>
        )}

        {/* Tasks List */}
        {loading ? (
          <div className="calm-card">
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 bg-muted rounded-xl" />
              ))}
            </div>
          </div>
        ) : tasks.length === 0 ? (
          <div className="calm-card text-center py-12">
            <div className="w-16 h-16 rounded-full bg-mint-light flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-8 h-8 text-mint" />
            </div>
            <h3 className="font-display font-semibold text-lg mb-2">No tasks yet</h3>
            <p className="text-muted-foreground mb-4">
              Add your first study task to get started!
            </p>
            <Button onClick={() => setShowForm(true)} variant="outline" className="calm-button">
              <Plus className="w-4 h-4 mr-2" />
              Add Task
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {subjects.map((subject) => (
              <div key={subject}>
                <h3 className="font-semibold text-sm text-muted-foreground mb-3 uppercase tracking-wide">
                  {subject}
                </h3>
                <div className="space-y-2">
                  {tasks
                    .filter((t) => t.subject === subject)
                    .map((task) => (
                      <div
                        key={task.id}
                        className={cn(
                          "calm-card flex items-center gap-4 py-4 transition-all",
                          task.completed && "opacity-60"
                        )}
                      >
                        <button
                          onClick={() => toggleComplete(task)}
                          className={cn(
                            "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all",
                            task.completed
                              ? "bg-mint border-mint text-primary-foreground"
                              : "border-border hover:border-mint"
                          )}
                        >
                          {task.completed && <Check className="w-4 h-4" />}
                        </button>
                        <div className="flex-1 min-w-0">
                          <p
                            className={cn(
                              "font-medium truncate",
                              task.completed && "line-through"
                            )}
                          >
                            {task.title}
                          </p>
                          {task.deadline && (
                            <div className={cn("flex items-center gap-1 text-sm", getDeadlineColor(task.deadline, task.completed))}>
                              <Calendar className="w-3 h-3" />
                              {getDeadlineLabel(task.deadline)}
                            </div>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteTask(task.id)}
                          className="text-muted-foreground hover:text-destructive shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
