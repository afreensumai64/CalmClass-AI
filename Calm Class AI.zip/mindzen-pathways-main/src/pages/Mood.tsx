import { useState, useEffect } from "react";
import { SmilePlus } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, isToday, isYesterday } from "date-fns";

type MoodType = "happy" | "calm" | "stressed" | "anxious" | "tired";

interface MoodEntry {
  id: string;
  mood: MoodType;
  note: string | null;
  created_at: string;
}

const moods: { type: MoodType; emoji: string; label: string; color: string }[] = [
  { type: "happy", emoji: "😊", label: "Happy", color: "bg-mood-happy" },
  { type: "calm", emoji: "😌", label: "Calm", color: "bg-mood-calm" },
  { type: "stressed", emoji: "😰", label: "Stressed", color: "bg-mood-stressed" },
  { type: "anxious", emoji: "😟", label: "Anxious", color: "bg-mood-anxious" },
  { type: "tired", emoji: "😴", label: "Tired", color: "bg-mood-tired" },
];

export default function Mood() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [todayLogged, setTodayLogged] = useState(false);

  useEffect(() => {
    fetchMoods();
  }, [user]);

  const fetchMoods = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from("moods")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(30);

    if (error) {
      toast({ title: "Error loading moods", variant: "destructive" });
    } else {
      setEntries((data || []).map(m => ({
        ...m,
        mood: m.mood as MoodType
      })));
      // Check if already logged today
      if (data && data.length > 0) {
        setTodayLogged(isToday(new Date(data[0].created_at)));
      }
    }
    setLoading(false);
  };

  const logMood = async () => {
    if (!user || !selectedMood) return;

    setSubmitting(true);

    const { error } = await supabase.from("moods").insert({
      user_id: user.id,
      mood: selectedMood,
      note: note.trim() || null,
    });

    if (error) {
      toast({ title: "Error logging mood", variant: "destructive" });
    } else {
      toast({ title: "Mood logged! 🌟" });
      setSelectedMood(null);
      setNote("");
      fetchMoods();
    }

    setSubmitting(false);
  };

  const getMoodInfo = (type: MoodType) => moods.find((m) => m.type === type)!;

  const getDateLabel = (dateStr: string) => {
    const date = new Date(dateStr);
    if (isToday(date)) return "Today";
    if (isYesterday(date)) return "Yesterday";
    return format(date, "MMM d");
  };

  // Calculate mood distribution
  const moodCounts = entries.reduce((acc, entry) => {
    acc[entry.mood] = (acc[entry.mood] || 0) + 1;
    return acc;
  }, {} as Record<MoodType, number>);

  const maxCount = Math.max(...Object.values(moodCounts), 1);

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-peach flex items-center justify-center">
            <SmilePlus className="w-6 h-6 text-orange-600" />
          </div>
          <div>
            <h1 className="font-display font-bold text-xl">Mood Tracker</h1>
            <p className="text-sm text-muted-foreground">
              {todayLogged ? "You've already logged today!" : "How are you feeling?"}
            </p>
          </div>
        </div>

        {/* Mood Selector */}
        <div className="calm-card">
          <h2 className="font-semibold mb-4">Log your mood</h2>
          <div className="grid grid-cols-5 gap-2 mb-4">
            {moods.map((mood) => (
              <button
                key={mood.type}
                onClick={() => setSelectedMood(mood.type)}
                className={cn(
                  "flex flex-col items-center gap-2 p-4 rounded-2xl transition-all duration-200",
                  selectedMood === mood.type
                    ? `${mood.color} scale-105 shadow-md`
                    : "bg-muted hover:bg-muted/80"
                )}
              >
                <span className="text-3xl">{mood.emoji}</span>
                <span className="text-xs font-medium">{mood.label}</span>
              </button>
            ))}
          </div>

          {selectedMood && (
            <div className="space-y-4 animate-fade-in">
              <Textarea
                placeholder="Add a note about how you're feeling... (optional)"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="calm-input resize-none"
                rows={3}
              />
              <div className="flex gap-2">
                <Button
                  onClick={logMood}
                  disabled={submitting}
                  className="calm-button"
                >
                  Log Mood
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => {
                    setSelectedMood(null);
                    setNote("");
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Mood Distribution */}
        {entries.length > 0 && (
          <div className="calm-card">
            <h2 className="font-semibold mb-4">Your mood distribution</h2>
            <div className="space-y-3">
              {moods.map((mood) => {
                const count = moodCounts[mood.type] || 0;
                const percentage = (count / maxCount) * 100;
                return (
                  <div key={mood.type} className="flex items-center gap-3">
                    <span className="text-xl w-8">{mood.emoji}</span>
                    <div className="flex-1 h-6 bg-muted rounded-full overflow-hidden">
                      <div
                        className={cn("h-full rounded-full transition-all duration-500", mood.color)}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="text-sm text-muted-foreground w-8 text-right">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Mood History */}
        <div className="calm-card">
          <h2 className="font-semibold mb-4">Recent entries</h2>
          {loading ? (
            <div className="animate-pulse space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 bg-muted rounded-xl" />
              ))}
            </div>
          ) : entries.length === 0 ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-peach flex items-center justify-center mx-auto mb-4">
                <SmilePlus className="w-8 h-8 text-orange-600" />
              </div>
              <p className="text-muted-foreground">No mood entries yet</p>
              <p className="text-sm text-muted-foreground">
                Select a mood above to get started!
              </p>
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {entries.map((entry) => {
                const moodInfo = getMoodInfo(entry.mood);
                return (
                  <div
                    key={entry.id}
                    className="flex items-start gap-3 p-4 bg-muted/50 rounded-xl"
                  >
                    <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-xl", moodInfo.color)}>
                      {moodInfo.emoji}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{moodInfo.label}</span>
                        <span className="text-sm text-muted-foreground">
                          {getDateLabel(entry.created_at)}
                        </span>
                      </div>
                      {entry.note && (
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {entry.note}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
