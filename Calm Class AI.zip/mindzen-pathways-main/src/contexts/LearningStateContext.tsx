import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from "react";

interface LearningSession {
  id: string;
  startTime: number;
  endTime?: number;
  lessonId: string;
  focusReadings: { time: number; value: number }[];
  breaksTaken: number;
  paceChanges: number;
}

interface LearningState {
  focus: number; // 0-100
  fatigue: number; // 0-100
  calm: number; // 0-100
}

interface LessonProgress {
  lessonId: string;
  title: string;
  progress: number; // 0-100
  lastAccessTime: number;
  mode: "text" | "slides" | "audio";
  pace: number; // 0.5 to 2.0
}

interface LearningStats {
  totalTimeStudied: number; // in seconds
  breaksTaken: number;
  sessionsCompleted: number;
  focusHistory: { time: number; value: number }[];
  emotionPatterns: {
    calm: number;
    fatigue: number;
    distraction: number;
  };
  bestLearningHour: number; // 0-23
}

interface LearningStateContextType {
  state: LearningState;
  stats: LearningStats;
  currentLesson: LessonProgress | null;
  insight: string | null;
  
  // Actions
  startLesson: (lessonId: string, title: string) => void;
  updateLessonProgress: (progress: number) => void;
  changePace: (pace: number) => void;
  changeMode: (mode: "text" | "slides" | "audio") => void;
  takeBreak: () => void;
  endLesson: () => void;
  tickLearning: () => void;
}

const STORAGE_KEY = "calmclass-learning-state";

const defaultState: LearningState = { focus: 70, fatigue: 20, calm: 80 };
const defaultStats: LearningStats = {
  totalTimeStudied: 0,
  breaksTaken: 0,
  sessionsCompleted: 0,
  focusHistory: [],
  emotionPatterns: { calm: 60, fatigue: 25, distraction: 15 },
  bestLearningHour: 10,
};

const LearningStateContext = createContext<LearningStateContextType | undefined>(undefined);

export function LearningStateProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<LearningState>(defaultState);
  const [stats, setStats] = useState<LearningStats>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        try {
          return { ...defaultStats, ...JSON.parse(stored) };
        } catch {
          return defaultStats;
        }
      }
    }
    return defaultStats;
  });
  const [currentLesson, setCurrentLesson] = useState<LessonProgress | null>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("calmclass-current-lesson");
      if (stored) {
        try {
          return JSON.parse(stored);
        } catch {
          return null;
        }
      }
    }
    return null;
  });
  const [insight, setInsight] = useState<string | null>(null);
  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null);

  // Persist stats
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  }, [stats]);

  // Persist current lesson
  useEffect(() => {
    if (currentLesson) {
      localStorage.setItem("calmclass-current-lesson", JSON.stringify(currentLesson));
    } else {
      localStorage.removeItem("calmclass-current-lesson");
    }
  }, [currentLesson]);

  // Generate insights based on state
  useEffect(() => {
    if (state.fatigue > 70) {
      setInsight("Detected fatigue — consider a micro-break. 🍵");
    } else if (state.focus > 80 && state.calm > 70) {
      setInsight("You're in a great learning flow! Keep it up. ✨");
    } else if (state.focus < 40) {
      setInsight("Focus seems low — try changing your learning mode.");
    } else if (state.calm < 40) {
      setInsight("Feeling a bit tense? A short breathing exercise might help.");
    } else {
      const hour = new Date().getHours();
      if (hour >= stats.bestLearningHour && hour <= stats.bestLearningHour + 2) {
        setInsight(`This is your peak focus time (${stats.bestLearningHour}:00 - ${stats.bestLearningHour + 2}:00).`);
      } else {
        setInsight(null);
      }
    }
  }, [state, stats.bestLearningHour]);

  const startLesson = useCallback((lessonId: string, title: string) => {
    setCurrentLesson((prev) => ({
      lessonId,
      title,
      progress: prev?.lessonId === lessonId ? prev.progress : 0,
      lastAccessTime: Date.now(),
      mode: prev?.lessonId === lessonId ? prev.mode : "text",
      pace: prev?.lessonId === lessonId ? prev.pace : 1,
    }));
    setSessionStartTime(Date.now());
    setState((prev) => ({ ...prev, focus: Math.min(100, prev.focus + 10) }));
  }, []);

  const updateLessonProgress = useCallback((progress: number) => {
    setCurrentLesson((prev) => prev ? { ...prev, progress: Math.min(100, progress) } : null);
  }, []);

  const changePace = useCallback((pace: number) => {
    setCurrentLesson((prev) => prev ? { ...prev, pace } : null);
    // Faster pace increases fatigue slightly
    if (pace > 1.2) {
      setState((prev) => ({
        ...prev,
        fatigue: Math.min(100, prev.fatigue + 5),
        focus: Math.max(0, prev.focus - 3),
      }));
    } else if (pace < 0.8) {
      // Slower pace reduces fatigue but may reduce focus
      setState((prev) => ({
        ...prev,
        fatigue: Math.max(0, prev.fatigue - 3),
        focus: Math.max(0, prev.focus - 2),
      }));
    }
  }, []);

  const changeMode = useCallback((mode: "text" | "slides" | "audio") => {
    setCurrentLesson((prev) => prev ? { ...prev, mode } : null);
    // Mode changes refresh focus slightly
    setState((prev) => ({
      ...prev,
      focus: Math.min(100, prev.focus + 5),
      fatigue: Math.max(0, prev.fatigue - 5),
    }));
  }, []);

  const takeBreak = useCallback(() => {
    setStats((prev) => ({ ...prev, breaksTaken: prev.breaksTaken + 1 }));
    setState((prev) => ({
      focus: Math.min(100, prev.focus + 15),
      fatigue: Math.max(0, prev.fatigue - 25),
      calm: Math.min(100, prev.calm + 20),
    }));
    setInsight("Break taken — feeling refreshed! 🌿");
  }, []);

  const endLesson = useCallback(() => {
    if (sessionStartTime) {
      const duration = Math.floor((Date.now() - sessionStartTime) / 1000);
      setStats((prev) => ({
        ...prev,
        totalTimeStudied: prev.totalTimeStudied + duration,
        sessionsCompleted: prev.sessionsCompleted + 1,
        focusHistory: [
          ...prev.focusHistory.slice(-50),
          { time: Date.now(), value: state.focus },
        ],
      }));
    }
    setSessionStartTime(null);
  }, [sessionStartTime, state.focus]);

  // Called periodically during learning to simulate focus/fatigue changes
  const tickLearning = useCallback(() => {
    if (!currentLesson || !sessionStartTime) return;

    const elapsed = (Date.now() - sessionStartTime) / 1000 / 60; // minutes

    setState((prev) => {
      // Natural fatigue increase over time
      let newFatigue = prev.fatigue + 0.5;
      // Focus decreases slowly
      let newFocus = prev.focus - 0.3;
      // Calm stays relatively stable
      let newCalm = prev.calm;

      // Adjust based on pace
      if (currentLesson.pace > 1.2) {
        newFatigue += 0.3;
        newFocus -= 0.2;
      } else if (currentLesson.pace < 0.8) {
        newFatigue -= 0.1;
      }

      // After 20 mins, fatigue increases faster
      if (elapsed > 20) {
        newFatigue += 0.5;
        newCalm -= 0.2;
      }

      return {
        focus: Math.max(0, Math.min(100, newFocus)),
        fatigue: Math.max(0, Math.min(100, newFatigue)),
        calm: Math.max(0, Math.min(100, newCalm)),
      };
    });

    // Update stats with focus reading
    setStats((prev) => ({
      ...prev,
      focusHistory: [
        ...prev.focusHistory.slice(-100),
        { time: Date.now(), value: state.focus },
      ],
      emotionPatterns: {
        calm: Math.round((prev.emotionPatterns.calm * 0.9 + state.calm * 0.1)),
        fatigue: Math.round((prev.emotionPatterns.fatigue * 0.9 + state.fatigue * 0.1)),
        distraction: Math.round((prev.emotionPatterns.distraction * 0.9 + (100 - state.focus) * 0.1)),
      },
    }));
  }, [currentLesson, sessionStartTime, state]);

  return (
    <LearningStateContext.Provider
      value={{
        state,
        stats,
        currentLesson,
        insight,
        startLesson,
        updateLessonProgress,
        changePace,
        changeMode,
        takeBreak,
        endLesson,
        tickLearning,
      }}
    >
      {children}
    </LearningStateContext.Provider>
  );
}

export function useLearningState() {
  const context = useContext(LearningStateContext);
  if (context === undefined) {
    throw new Error("useLearningState must be used within a LearningStateProvider");
  }
  return context;
}
