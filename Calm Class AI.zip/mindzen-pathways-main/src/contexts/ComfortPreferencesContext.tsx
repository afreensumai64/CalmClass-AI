import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type FontType = "default" | "opendyslexic";
export type ColorTheme = "calm-blue" | "low-contrast";
export type AnimationMode = "minimal" | "standard";

interface ComfortPreferences {
  font: FontType;
  colorTheme: ColorTheme;
  animationMode: AnimationMode;
  notificationsEnabled: boolean;
  emotionTrackingEnabled: boolean;
}

interface ComfortPreferencesContextType {
  preferences: ComfortPreferences;
  updatePreference: <K extends keyof ComfortPreferences>(
    key: K,
    value: ComfortPreferences[K]
  ) => void;
  isMinimalAnimations: boolean;
}

const defaultPreferences: ComfortPreferences = {
  font: "default",
  colorTheme: "calm-blue",
  animationMode: "standard",
  notificationsEnabled: true,
  emotionTrackingEnabled: true,
};

const STORAGE_KEY = "calmclass-comfort-preferences";

const ComfortPreferencesContext = createContext<ComfortPreferencesContextType | undefined>(undefined);

export function ComfortPreferencesProvider({ children }: { children: ReactNode }) {
  const [preferences, setPreferences] = useState<ComfortPreferences>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        try {
          return { ...defaultPreferences, ...JSON.parse(stored) };
        } catch {
          return defaultPreferences;
        }
      }
    }
    return defaultPreferences;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));
    
    // Apply font preference
    const root = document.documentElement;
    if (preferences.font === "opendyslexic") {
      root.classList.add("font-opendyslexic");
    } else {
      root.classList.remove("font-opendyslexic");
    }

    // Apply color theme
    if (preferences.colorTheme === "low-contrast") {
      root.classList.add("low-contrast");
    } else {
      root.classList.remove("low-contrast");
    }

    // Apply animation mode
    if (preferences.animationMode === "minimal") {
      root.classList.add("reduce-motion");
    } else {
      root.classList.remove("reduce-motion");
    }
  }, [preferences]);

  const updatePreference = <K extends keyof ComfortPreferences>(
    key: K,
    value: ComfortPreferences[K]
  ) => {
    setPreferences((prev) => ({ ...prev, [key]: value }));
  };

  const isMinimalAnimations = preferences.animationMode === "minimal";

  return (
    <ComfortPreferencesContext.Provider value={{ preferences, updatePreference, isMinimalAnimations }}>
      {children}
    </ComfortPreferencesContext.Provider>
  );
}

export function useComfortPreferences() {
  const context = useContext(ComfortPreferencesContext);
  if (context === undefined) {
    throw new Error("useComfortPreferences must be used within a ComfortPreferencesProvider");
  }
  return context;
}
