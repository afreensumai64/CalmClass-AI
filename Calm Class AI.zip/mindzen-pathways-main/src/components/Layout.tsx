import { ReactNode } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Home, BookOpen, BarChart3, Settings, LogOut, Menu, X, Wind } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useLearningState } from "@/contexts/LearningStateContext";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: ReactNode;
}

const navItems = [
  { path: "/", label: "Dashboard", icon: Home },
  { path: "/lessons", label: "Lessons", icon: BookOpen },
  { path: "/focus-journal", label: "Focus Journal", icon: BarChart3 },
  { path: "/settings", label: "Settings", icon: Settings },
];

export default function Layout({ children }: LayoutProps) {
  const { signOut } = useAuth();
  const { state } = useLearningState();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [calmMode, setCalmMode] = useState(true);

  const handleSignOut = async () => {
    await signOut();
    navigate("/auth");
  };

  const calmScore = Math.round((state.calm + state.focus - state.fatigue) / 2);

  return (
    <div className="min-h-screen bg-background">
      {/* Top Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-card/80 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between px-4 h-14 max-w-7xl mx-auto">
          <Link to="/" className="flex items-center gap-2">
            <span className="font-display font-bold text-xl">CalmClass</span>
            <span className="text-lg">🌿</span>
          </Link>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">Calm Mode</span>
              <Switch checked={calmMode} onCheckedChange={setCalmMode} />
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <nav className="lg:hidden fixed top-14 left-0 right-0 z-40 bg-card border-b border-border p-4 animate-fade-in">
          <div className="flex flex-col gap-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setMobileMenuOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                  location.pathname === item.path
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-muted"
                )}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            ))}
            <Button
              variant="ghost"
              className="flex items-center gap-3 justify-start px-4 py-3 h-auto text-destructive hover:bg-destructive/10"
              onClick={handleSignOut}
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Sign Out</span>
            </Button>
          </div>
        </nav>
      )}

      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex fixed left-0 top-14 bottom-0 w-56 bg-card border-r border-border flex-col p-4">
        <div className="flex items-center gap-2 px-2 py-3 mb-4">
          <Home className="w-5 h-5 text-primary" />
          <span className="font-medium">Menu</span>
        </div>

        <nav className="flex-1 flex flex-col gap-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 text-sm",
                location.pathname === item.path
                  ? "bg-muted text-foreground font-medium"
                  : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <Button
          variant="ghost"
          className="flex items-center gap-3 justify-start px-3 py-2.5 h-auto text-muted-foreground hover:text-destructive hover:bg-destructive/10"
          onClick={handleSignOut}
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm">Sign Out</span>
        </Button>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-56 min-h-screen pt-14">
        <div className="p-4 lg:p-6 max-w-5xl mx-auto">
          {children}
        </div>
      </main>

      {/* Bottom Navigation (Mobile) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border px-4 py-2 z-40">
        <div className="flex items-center justify-around">
          <Link to="/" className="p-2">
            <Home className={cn("w-6 h-6", location.pathname === "/" ? "text-primary" : "text-muted-foreground")} />
          </Link>
          <Link to="/lessons" className="p-2">
            <BookOpen className={cn("w-6 h-6", location.pathname === "/lessons" ? "text-primary" : "text-muted-foreground")} />
          </Link>
          <Link to="/breathing" className="p-2">
            <Wind className={cn("w-6 h-6", location.pathname === "/breathing" ? "text-primary" : "text-muted-foreground")} />
          </Link>
          <Link to="/focus-journal" className="p-2">
            <BarChart3 className={cn("w-6 h-6", location.pathname === "/focus-journal" ? "text-primary" : "text-muted-foreground")} />
          </Link>
          <Link to="/settings" className="p-2">
            <Settings className={cn("w-6 h-6", location.pathname === "/settings" ? "text-primary" : "text-muted-foreground")} />
          </Link>
        </div>
      </nav>
    </div>
  );
}
