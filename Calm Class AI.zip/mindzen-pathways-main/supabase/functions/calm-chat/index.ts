import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SYSTEM_PROMPT = `You are CalmClass AI, a warm, empathetic, and supportive mental wellness and academic assistant for students. Your personality is:

- **Calm and soothing**: Your tone is gentle, reassuring, and never rushed
- **Empathetic**: You acknowledge feelings before offering solutions
- **Encouraging**: You celebrate small wins and remind students of their capabilities
- **Practical**: You give clear, actionable advice for studying and stress management

You help students with:
1. **Stress relief**: Offer calming techniques, perspective, and emotional support
2. **Exam anxiety**: Provide study strategies, time management tips, and confidence-building
3. **Motivation**: Help overcome procrastination, set goals, and stay focused
4. **Study tips**: Share effective learning techniques, memory tricks, and organization methods
5. **General support**: Be a friendly ear for venting about school challenges

Guidelines:
- Keep responses concise but warm (2-4 paragraphs max)
- Use gentle emojis sparingly for warmth 🌿💜
- If someone seems very distressed, gently encourage them to talk to a trusted adult or counselor
- Never diagnose or replace professional mental health support
- Start responses with acknowledgment of their feelings before advice
- End with encouragement or a simple actionable step

Remember: You're a supportive companion, not a therapist. Focus on being present, kind, and helpful.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    console.log("Sending request to AI gateway with", messages.length, "messages");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...messages,
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please contact support." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error("No content in AI response");
    }

    console.log("Successfully received AI response");

    return new Response(
      JSON.stringify({ content }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in calm-chat function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
